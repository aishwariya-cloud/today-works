package com.example.demo.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.example.demo.model.User;

public class ReadyGoDAO {
	public static Connection connectToDB()
	{
		Connection connection=null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		  connection = DriverManager.getConnection("jdbc:oracle:thin:localhost:1521:xe","scott","admin");
		  System.out.println();
			return connection;
		} 
		catch (ClassNotFoundException | SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			
				try {
					connection.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				return null;
		}
		
		
	}
	public void addUser(User user) {
		Connection con=connectToDB();
		try {
			PreparedStatement stmt = con.prepareStatement("insert into books values(?,?,?,?,?,?,?,?)");
			stmt.setInt(1, user.getUserId());
			stmt.setString(2,user.getUserName());
			stmt.setInt(3, user.getContact());
			stmt.setString(4, user.geteMail());
			stmt.setString(5, user.getAddress());
			stmt.setString(6, user.getCity());
			stmt.setString(7, user.getPassword());
			stmt.setBoolean(8, user.isRole());
			int affectedRows = stmt.executeUpdate();
			System.out.println("Affected rows " + affectedRows);
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
