package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.model.User;
import com.example.demo.services.UserService;

public class UserController {
	@Autowired
	UserService userService;
	
	
	@RequestMapping("/")
	public void addUser(@RequestParam ("UserId")int userId,@RequestParam("UserName")String userName,@RequestParam("ContactNo")int contact,
			@RequestParam("E-Mail") String eMail,@RequestParam("Address") String address,@RequestParam("City") String city,@RequestParam("password")String password,@RequestParam("Role")boolean role) {
	User user =new User();
	user.setUserId(userId);
	user.setUserName(userName);
	user.setContact(contact);
	user.seteMail(eMail);
	user.setAddress(address);
	user.setCity(city);
	user.setPassword(password);
	user.setRole(role);
	userService.addUser(user);
	}

}
