package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.DAO.ReadyGoDAO;
import com.example.demo.model.User;

public class UserService {
@Autowired
ReadyGoDAO dao;
public void addUser(User user) {
	dao.addUser(user);
}
	
	
	
	

}
